import Portfolio from "../portfolio"

export default function Page() {
  return <Portfolio />
}
